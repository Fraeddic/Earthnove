#!/bin/sh
echo -ne '\033c\033]0;Retro Low Poly Adventure Game\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/Earthnove 0.1 Proto.x86_64" "$@"
